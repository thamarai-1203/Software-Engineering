package de.buw.se4de;

import java.util.Scanner;

public class App {
	
	static String PATH_DOC_CSV = "src/main/resources/doctors.csv";
	static String PATH_PATIENT_CSV = "src/main/resources/patients.csv";
	static String PATH_APPOINTMENT_CSV = "src/main/resources/appointments.csv";
	static String DIVISION = "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -";

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome to the Doc Appointment Booking Application!");
		System.out.println(App.DIVISION);
		
		Patient patient = new Patient();
		Appointments ap = new Appointments();
		
		System.out.println(App.DIVISION);
	    System.out.println("Do you want to book or cancel an appointment? Enter 'book' or 'cancel'");
		String choice = sc.nextLine();
		
		if(choice.toLowerCase().equals("book")) {
			Doctors doc = new Doctors();
			doc.displayDoc();
			String chosen_doc = doc.chooseDoc();
			ap.bookAppointment(chosen_doc, patient.getName());
			
		}
		else if(choice.toLowerCase().equals("cancel")) {
			ap.cancelAppointment(patient.getName());
		}
		
		
		
		
	}	

}
