package de.buw.se4de;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Appointments {
	
	private List<ArrayList<String>> appointment_data;
	private HashMap<String,HashMap<String,ArrayList<String>>> bookings_doc;
	private HashMap<String,HashMap<String,ArrayList<String>>> appointments_patient;
	private Doctors doc;
	private registeredPatients reg_patients;
	private CSVScanner csvReader;
	private Scanner sc;
	private String[] TIME_SLOTS = {"8am", "9am", "10am", "11am", "1pm", "2pm", "3pm", "4pm"};
	
	public Appointments() {
		this.csvReader = new CSVScanner();
		this.sc = new Scanner(System.in);
		this.doc = new Doctors();
		this.reg_patients = new registeredPatients();
		this.bookings_doc = new HashMap<String,HashMap<String,ArrayList<String>>>();
		this.appointments_patient = new HashMap<String,HashMap<String,ArrayList<String>>>();
		this.loadData();
	}
	
	public void loadData() {
		
		this.appointment_data = csvReader.readCSV(App.PATH_APPOINTMENT_CSV);
		
		for(String doc : this.doc.get_array_of_doc()) {
			
			HashMap<String,ArrayList<String>> date = new HashMap<String,ArrayList<String>>();
			
			for(ArrayList<String> appointment : this.appointment_data) {
				String key = appointment.get(2);
				String value = appointment.get(3);
				if(appointment.get(1).equals(doc)) {
					
					if(date.containsKey(key)) {
						ArrayList<String> times = date.get(key);
						times.add(value);
						date.put(key, times);
					}
					else if(!date.containsKey(key)) {
						ArrayList<String> times = new ArrayList<String>();
						times.add(value);
						date.put(key, times);
						
					}
					
				}
		
			}
			
			this.bookings_doc.put(doc, date);
		}
		
		for(String patient : this.reg_patients.get_array_of_patients()) {
			
            HashMap<String,ArrayList<String>> date = new HashMap<String,ArrayList<String>>();
			
			for(ArrayList<String> appointment : this.appointment_data) {
				String key = appointment.get(2);
				String value = appointment.get(3);
				
				if(appointment.get(1).equals(patient)) {
					
					if(date.containsKey(key)) {
						ArrayList<String> times = date.get(key);
						times.add(value);
						date.put(key, times);
					}
					else if(!date.containsKey(key)) {
						ArrayList<String> times = new ArrayList<String>();
						times.add(value);
						date.put(key, times);
					}
					
				}
		
			}
			
			this.appointments_patient.put(patient, date);
		}		
			
	}
	
	public void bookAppointment(String doc, String patient_name) {
		String date = this.selectDate(doc);
		ArrayList<String> times = this.availableTimes(doc, date);
		
		System.out.println(App.DIVISION);
		System.out.println("Please select the time for your appointment. You can choose between...");
		for(String t : times) {
			System.out.println("  - " + t);
		}
		System.out.println("\nPlease enter a time:");
		String time = sc.nextLine();
		
		System.out.println(App.DIVISION);
		System.out.println("You have successfully booked your appointment:\n"
				         + "Where: " + doc + "\n"
				         + "       " + this.doc.get_street(doc) + "\n"
				         + "       " + this.doc.get_place(doc) + "\n"
				         + "When:  " + date + " at " + time);
		
		ArrayList<String> new_appointment = new ArrayList<String>();
		new_appointment.add(patient_name);
		new_appointment.add(doc);
		new_appointment.add(date);
		new_appointment.add(time);
		this.csvReader.addToFile(new_appointment, "appointments");
			
	}
	
	public String selectDate(String doc) {
		System.out.println(App.DIVISION);
		System.out.println("Please select a date for your appointment: Enter (dd/mm/jjjj) ");
		String date = sc.nextLine();
		
		HashMap<String,ArrayList<String>> bookings = new HashMap<String,ArrayList<String>>();
		if(this.bookings_doc.containsKey(doc)) {
			bookings = this.bookings_doc.get(doc);
		}
		
		Boolean found_date = false;
		
		while(!found_date) {
			if(!bookings.containsKey(date) || bookings.get(date).size() < 8) {
				found_date = true;
			}
			else {
				System.out.println(App.DIVISION);
				System.out.println("The day you have selected is already fully booked!");
				System.out.println("Please select another date for your appointment: Enter (dd/mm/jjjj) ");
				date = sc.nextLine();
			}
		}
		
		return date;
	}
	
	public ArrayList<String> availableTimes(String doc, String date) {
		
		HashMap<String,ArrayList<String>> bookings = new HashMap<String,ArrayList<String>>();
		if(this.bookings_doc.containsKey(doc)) {
			bookings = this.bookings_doc.get(doc);
		}

		ArrayList<String> available_times = new ArrayList<String>();
		ArrayList<String> booked_times = new ArrayList<String>();
		if(bookings.containsKey(date)) {
			booked_times = bookings.get(date);
		}
		
		
		for(String time : this.TIME_SLOTS) {
			
			if(!booked_times.contains(time)) {
				available_times.add(time);
				
			}
		}
		
		return available_times;
	}
	
	public void cancelAppointment(String patient_name) {
		System.out.println(App.DIVISION);
		if(this.appointments_patient.get(patient_name) == null) {
			System.out.println("You have no appointments to cancel!");
		}
		else {
			System.out.println("Which appointment do you want to cancel:");
			this.displayAppointments(patient_name);
			System.out.println("\nPlease enter a number:");
			String choice = sc.nextLine();
		    int num = Integer.parseInt(choice);
			this.deleteAppointment(patient_name, num);
			System.out.println(App.DIVISION);
			System.out.println("You have successfully canceled your appointment!");
			
		}
	}
	
	public void displayAppointments(String patient_name) {
		int i = 1;
		for(ArrayList<String> appointment : this.appointment_data) {
			if(appointment.get(0).equals(patient_name)) {
				System.out.println("  (" + i + ") On the " + appointment.get(2) + " at " + appointment.get(3) + " at " 
			                       + appointment.get(1));
				i++;
			}
		}
		
	}
	
	public void deleteAppointment(String patient_name, int choice) {
		int num = 0;
		for(ArrayList<String> appointment : this.appointment_data) {
			if(appointment.get(0).equals(patient_name)) {
				num++;
				if(choice == num) {
					this.csvReader.removeFromFile(appointment, "appointments");
				}
			}
		}
	}
	
	
	
	
	

}
