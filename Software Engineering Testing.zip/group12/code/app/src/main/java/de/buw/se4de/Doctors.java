package de.buw.se4de;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Doctors {
	
	private HashMap<String,HashMap<String,String>> doctors;
	private String [] list_of_docs;
	private CSVScanner csvReader = new CSVScanner();
	private Scanner scan;
	
	public Doctors() {
		this.scan = new Scanner(System.in);
		this.doctors = new HashMap<String,HashMap<String,String>>();
		this.loadData();
		
		Set<String> keys = this.doctors.keySet();
		this.list_of_docs = new String[keys.size()];
		keys.toArray(this.list_of_docs);
	}
	
	public void loadData() {
		
		List<ArrayList<String>> import_data = new ArrayList<ArrayList<String>>();
		import_data = csvReader.readCSV(App.PATH_DOC_CSV);
		
		for(ArrayList<String> doc_list : import_data) {
			HashMap<String,String> doc_info = new HashMap<String,String>();
			doc_info.put("speciality", doc_list.get(1));
			doc_info.put("street", doc_list.get(2));
			doc_info.put("place", doc_list.get(3));
			
			this.doctors.put(doc_list.get(0), doc_info);
		}
		
	}
	
	public void displayDoc() {
		System.out.println(App.DIVISION);
		System.out.println("You can choose between the following doctors:");
		
		int n = 0;
		for(String doc : this.list_of_docs) {
			n++;
			HashMap<String,String> info = this.doctors.get(doc);
			System.out.println("  (" + n + ") " + info.get("speciality") + " - " + doc);
		}
		
	}
	
	public String chooseDoc() {
		System.out.println("\nPlease enter a number:");
		String choice = this.scan.nextLine();
		int num = Integer.parseInt(choice);
		
		return this.list_of_docs[num - 1];
	}
	
	public String[] get_array_of_doc() {
		return this.list_of_docs;
	}
	
	public String get_street(String doc) {
		HashMap<String,String> info = this.doctors.get(doc);
		return info.get("street");
	}
	
	public String get_place(String doc) {
		HashMap<String,String> info = this.doctors.get(doc);
		return info.get("place");
	}
	

}
