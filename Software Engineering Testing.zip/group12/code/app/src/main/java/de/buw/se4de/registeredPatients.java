package de.buw.se4de;

import java.util.ArrayList;
import java.util.List;

public class registeredPatients {
	
	private List<ArrayList<String>> patients_data;
	private CSVScanner csvReader = new CSVScanner();
	
	public registeredPatients() {
		this.patients_data = csvReader.readCSV(App.PATH_PATIENT_CSV);
	}
	
	public String[] get_array_of_patients() {
		String[] array_of_patients = new String[this.patients_data.size()];
		int i = 0;
		for(ArrayList<String> patient : this.patients_data) {
			array_of_patients[i] = patient.get(0);
			i++;
		}
		
		return array_of_patients;
		
	}
	
	public List<ArrayList<String>> get_patients_data() {
		return this.patients_data;
	}

}
