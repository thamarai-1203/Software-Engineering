# java-gradle-template
A template java project using gradle and basic dependencies

It basically follows the tutorial described here: https://docs.gradle.org/current/samples/sample_building_java_applications.html

I have added an example dependency that reads a CSV file (many of you look like they want something like that). A tutorial is here: https://www.callicoder.com/java-read-write-csv-file-apache-commons-csv/

There are different options for reading input from the console: https://www.geeksforgeeks.org/ways-to-read-input-from-console-in-java/
