# java-gradle-template
Java project implementing the functionality of "Expected return of investment" using gradle and basic dependencies.

This is a console application and it works by showing information to the user based on the input provided in the console.

Assumptions are made on the following aspects since they are not clearly mentioned in the requirements document:
* The type of application (console)
* Formulas for calculating investment returns.
* Invest suggestions shown to the user
* Sponsor details

