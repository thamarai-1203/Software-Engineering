package de.buw.se4de;

public class ReturnsCalculation {
	
	public static void calculateInterestOnSavingsAccount(int investmentAmount, int years) {
		double savingsReturns = 0.0006;
		double compoundedVal = investmentAmount;
		for(int i=1; i<=years*12; i++) {
			compoundedVal = compoundedVal+(compoundedVal*savingsReturns);
		}
		System.out.println("With a "+(savingsReturns*100)+"% returns, "+
				"Your total amount (in EUR) after "+years+" years will be: "+ compoundedVal);
	}
	
	public static void calculateInterestOnStocks(int investmentAmount, int years) {
		double returnsPercentWithoutDiv = 0.06;
		double returnsPercentWithDiv = 0.12;
		double returnsWithoutDiv = investmentAmount+(investmentAmount*years*returnsPercentWithoutDiv);
		double returnsWithDiv = investmentAmount+(investmentAmount*years*returnsPercentWithDiv);
		System.out.println("With "+(returnsPercentWithoutDiv*100)+"% returns without Dividends, "+
				"Your total amount (in EUR) after "+years+" years will be: "+ returnsWithoutDiv);
		System.out.println("With "+(returnsPercentWithDiv*100)+"% returns with Dividends, "+
				"Your total amount (in EUR) after "+years+" years will be: "+ returnsWithDiv);


            System.out.println("\n\n\n While comparing with other alternative investiment options");
            double cryptoReturns1 = 0.06;
		double returnAmount1 = investmentAmount+(investmentAmount*years*cryptoReturns1);
		System.out.println("\n1. Investing in Cryptos: "+ returnAmount1);


            double bondsReturns2 = 0.0712;
		double returnAmount2 = investmentAmount+(investmentAmount*years*bondsReturns2);
            System.out.println("2. Investing in Bonds:     "+ returnAmount2);
           
            double ETFReturns3 = 0.0812;
		double returnAmount3 = investmentAmount+(investmentAmount*years*ETFReturns3);
		System.out.println("3. Investing in ETF:       "+ returnAmount3);
            
            double P2PReturns4 = 0.1012;
		double returnAmount4 = investmentAmount+(investmentAmount*years*P2PReturns4);
		System.out.println("4. Investing in P2P:       "+ returnAmount4);
            

            

	}
	
	public static void calculateInterestOnCryptos(int investmentAmount, int years) {
		double cryptoReturns = 0.06;
		double returnAmount = investmentAmount+(investmentAmount*years*cryptoReturns);
		System.out.println("With "+(cryptoReturns*100)+"% returns, "+
				"Your total amount (in EUR) after "+years+" years will be: "+ returnAmount);


            System.out.println("\n\n\n While comparing with other alternative investiment options");
            
            double returnsPercentWithoutDiv51 = 0.06;
		double returnsPercentWithDiv51 = 0.12;
		double returnsWithoutDiv51 = investmentAmount+(investmentAmount*years*returnsPercentWithoutDiv51);
		double returnsWithDiv51 = investmentAmount+(investmentAmount*years*returnsPercentWithDiv51);
		System.out.println("\n1a. Investing in Stocks Without Dividend: "+ returnsWithoutDiv51);
		System.out.println("1b. Investing in stocks with Devidend:      "+ returnsWithDiv51);            

            double bondsReturns21 = 0.0712;
		double returnAmount21 = investmentAmount+(investmentAmount*years*bondsReturns21);
            System.out.println("2. Investing in Bonds:   "+ returnAmount21);
           
            double ETFReturns31 = 0.0812;
		double returnAmount31 = investmentAmount+(investmentAmount*years*ETFReturns31);
		System.out.println("3. Investing in ETF:    "+ returnAmount31);
            
            double P2PReturns41 = 0.1012;
		double returnAmount41 = investmentAmount+(investmentAmount*years*P2PReturns41);
		System.out.println("4. Investing in P2P:     "+ returnAmount41);
            
            

	}
	
	public static void calculateInterestOnBonds(int investmentAmount, int years) {
		double bondsReturns = 0.0712;
		double returnAmount = investmentAmount+(investmentAmount*years*bondsReturns);
		System.out.println("With "+(bondsReturns*100)+"% returns, "+
				"Your total amount (in EUR) after "+years+" years will be: "+ returnAmount);

            System.out.println("\n\n\n While comparing with other alternative investiment options");
            double returnsPercentWithoutDiv52 = 0.06;
		double returnsPercentWithDiv52 = 0.12;
		double returnsWithoutDiv52 = investmentAmount+(investmentAmount*years*returnsPercentWithoutDiv52);
		double returnsWithDiv52 = investmentAmount+(investmentAmount*years*returnsPercentWithDiv52);
		System.out.println("\n1a. Investing in Stocks Without Dividend: "+ returnsWithoutDiv52);
		System.out.println("1b. Investing in stocks with Devidend:      "+ returnsWithDiv52);

            double cryptoReturns12 = 0.06;
		double returnAmount12 = investmentAmount+(investmentAmount*years*cryptoReturns12);
		System.out.println("2. Investing in Cryptos: "+ returnAmount12);

            double ETFReturns32 = 0.0812;
		double returnAmount32 = investmentAmount+(investmentAmount*years*ETFReturns32);
		System.out.println("3. Investing in ETF:    "+ returnAmount32);
            
            double P2PReturns42 = 0.1012;
		double returnAmount42 = investmentAmount+(investmentAmount*years*P2PReturns42);
		System.out.println("4. Investing in P2P:     "+ returnAmount42);
            
            
	}

      public static void calculateInterestOnETF(int investmentAmount, int years) {
		double ETFReturns = 0.0812;
		double returnAmount = investmentAmount+(investmentAmount*years*ETFReturns);
		System.out.println("With "+(ETFReturns*100)+"% returns, "+
				"Your total amount (in EUR) after "+years+" years will be: "+ returnAmount);

            System.out.println("\n\n\n While comparing with other alternative investiment options");
            double returnsPercentWithoutDiv53 = 0.06;
		double returnsPercentWithDiv53 = 0.12;
		double returnsWithoutDiv53 = investmentAmount+(investmentAmount*years*returnsPercentWithoutDiv53);
		double returnsWithDiv53 = investmentAmount+(investmentAmount*years*returnsPercentWithDiv53);
		System.out.println("\n1a. Investing in Stocks Without Dividend: "+ returnsWithoutDiv53);
		System.out.println("1b. Investing in stocks with Devidend:      "+ returnsWithDiv53);

            double cryptoReturns13 = 0.06;
		double returnAmount13 = investmentAmount+(investmentAmount*years*cryptoReturns13);
		System.out.println("2. Investing in Cryptos: "+ returnAmount13);

	      double bondsReturns23 = 0.0712;
		double returnAmount23 = investmentAmount+(investmentAmount*years*bondsReturns23);
            System.out.println("3. Investing in Bonds:   "+ returnAmount23);

            double P2PReturns43 = 0.1012;
		double returnAmount43 = investmentAmount+(investmentAmount*years*P2PReturns43);
		System.out.println("4. Investing in P2P:     "+ returnAmount43);
           
	}

      public static void calculateInterestOnP2P(int investmentAmount, int years) {
		double P2PReturns = 0.1012;
		double returnAmount = investmentAmount+(investmentAmount*years*P2PReturns);
		System.out.println("With "+(P2PReturns*100)+"% returns, "+
				"Your total amount (in EUR) after "+years+" years will be: "+ returnAmount);

	      System.out.println("\n\n\n While comparing with other alternative investiment options");
            double returnsPercentWithoutDiv54 = 0.06;
		double returnsPercentWithDiv54 = 0.12;
		double returnsWithoutDiv54 = investmentAmount+(investmentAmount*years*returnsPercentWithoutDiv54);
		double returnsWithDiv54 = investmentAmount+(investmentAmount*years*returnsPercentWithDiv54);
		System.out.println("\n1a. Investing in Stocks Without Dividend: "+ returnsWithoutDiv54);
		System.out.println("1b. Investing in stocks with Devidend:      "+ returnsWithDiv54);

            double cryptoReturns14 = 0.06;
		double returnAmount14 = investmentAmount+(investmentAmount*years*cryptoReturns14);
		System.out.println("2. Investing in Cryptos: "+ returnAmount14);

            double bondsReturns24 = 0.0712;
		double returnAmount24 = investmentAmount+(investmentAmount*years*bondsReturns24);
            System.out.println("3. Investing in Bonds:   "+ returnAmount24);

            double ETFReturns34 = 0.0812;
		double returnAmount34 = investmentAmount+(investmentAmount*years*ETFReturns34);
		System.out.println("4. Investing in ETF:    "+ returnAmount34);


	}
	
	public static void calculateInflationOnMoneyAtHome(int investmentAmount, int years) {
		double expectedInflation = 0.01;
		double effAmount = investmentAmount - (investmentAmount*expectedInflation*years);
		System.out.println("With an inflation rate of "+(expectedInflation*100)+"%, "+
				"Your total amount (in EUR) after "+years+" years will be: "+ effAmount);
	}
}
