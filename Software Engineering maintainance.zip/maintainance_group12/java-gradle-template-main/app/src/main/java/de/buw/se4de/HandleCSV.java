package de.buw.se4de;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
public class HandleCSV {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static String getValueUsingReference(String fileName, String refColName, String refColValue, String actualColName) {
		try (Reader reader = Files.newBufferedReader(Paths.get(fileName));
				@SuppressWarnings("deprecation")
				CSVParser csvParser = new CSVParser(reader,
						CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {
			for (CSVRecord csvRecord : csvParser) {
				String name = csvRecord.get(refColName);
				if(name.equalsIgnoreCase(refColValue))
					return csvRecord.get(actualColName);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}