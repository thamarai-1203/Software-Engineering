package de.buw.se4de;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Helper {
	public static int handleNumberChoiceExceptions(int... valRange) {
		int inputValue = 0;
		boolean flag = false;
		do {
			try {
				Scanner sc = new Scanner(System.in);
				inputValue = sc.nextInt(); 
				if(valRange.length==1) {
					if(inputValue<valRange[0])
						throw new NegativeNumberException();
					flag=true;
				}
				else {
					if(inputValue<valRange[0] || inputValue>valRange[1])
						throw new Exception();
					flag=true;
				}
			} catch (InputMismatchException e) {
				try {
					System.err.println("Invalid input! Enter a numeric value without decimals in the range of "+ valRange[0]+ " to "+ valRange[1]+":");
				} catch (ArrayIndexOutOfBoundsException aioe) {
					System.err.println("Invalid input! Enter a numeric value without decimals:");
				}
			}
			catch(NegativeNumberException ne) {
				System.err.println("This value cannot be negative. Enter a positive integer without decimals:");
			}
			catch(Exception ex) {
				try {
					System.err.println("Invalid input! Enter a value in the range of "+ valRange[0]+ " to "+ valRange[1]+":");
				} catch (ArrayIndexOutOfBoundsException aioe) {
					System.err.println("Invalid input! Enter a numeric value without decimals:");
				}
			}
		}while(flag==false);
		return inputValue;
	}
	
	//
	public static String handleStringChoiceExceptions(String... stringVals) {
		String inputValue = "";
		boolean flag = false;
		ArrayList<String> acceptedVals = new ArrayList<String>();
		Collections.addAll(acceptedVals, stringVals);
		do {
			try {
				Scanner sc = new Scanner(System.in);
				inputValue = sc.nextLine(); 
				if(!acceptedVals.contains(inputValue.toLowerCase()))
					throw new InvalidValueException();
				flag=true;
			}catch (InputMismatchException | InvalidValueException e) {
				System.err.println("Invalid input! Valid values are:: "+ acceptedVals);
			}
			catch(Exception ex) {
				ex.printStackTrace();
			}
		}while(flag==false);
		return inputValue;
	}
	
}
