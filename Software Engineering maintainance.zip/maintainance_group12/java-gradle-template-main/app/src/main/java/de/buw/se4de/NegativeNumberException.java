package de.buw.se4de;

public class NegativeNumberException extends Exception{
	
	
}
