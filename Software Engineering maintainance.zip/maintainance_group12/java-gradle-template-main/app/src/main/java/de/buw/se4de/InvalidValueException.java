package de.buw.se4de;

public class InvalidValueException extends Exception{

}
